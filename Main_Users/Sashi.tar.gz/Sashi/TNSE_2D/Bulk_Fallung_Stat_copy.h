// copy of example Bulk_Fallung_Stat.h

void BoundCondition(int i, double t, BoundCond &cond);
void U1BoundValue(int BdComp, double Param, double &value);
void U2BoundValue(int BdComp, double Param, double &value);













